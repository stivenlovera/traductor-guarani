$(document).ready(function(){
    $('.sidenav').sidenav();
  });
  
  M.textareaAutoResize($('#textarea1'));



